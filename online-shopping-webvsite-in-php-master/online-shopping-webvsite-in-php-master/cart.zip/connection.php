<?php
$con=mysqli_connect("database-1.cspilfowve69.us-east-1.rds.amazonaws.com","admin","admin123","store") or die(mysqli_error($con));
//$con=mysqli_connect("localhost","root","","store") or die(mysqli_error($con));
?>
